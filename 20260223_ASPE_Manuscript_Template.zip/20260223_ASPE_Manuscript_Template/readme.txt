## readme.txt

This repository contains the LaTeX templates needed to properly format manuscripts for conference proceedings of the American Society for Precision Engineering. The files were originally written by Hans-Jochen Trost of MicroFab Technologies, lightly edited in 2019 to remove out-of-date content, and last compiled in [Overleaf](https://www.overleaf.com) on March 18, 2019.
It was later edited by Stuart Smith, Steve Lugwick, and Kumar Arumugam in 2025 and 2026.

Please direct any questions or comments to the ASPE at <executive@aspe.net>

- end -